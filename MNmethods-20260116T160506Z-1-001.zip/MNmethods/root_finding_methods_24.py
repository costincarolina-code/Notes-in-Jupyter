#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 10:41:51 2024

@author: frison
"""
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.optimize as opt

# Relaxation method for x = f(x)
def relax(f, x = 1., err = 1e-6, nlim = int(1e5)):
    ni = int(0)
    xold = x + 1.
    while (abs(x - xold) > err):
        xold = x
        x = f(x)
        ni += 1
        if ni >= int(nlim):
            x = float('inf')
            print('There was no convergence after {} interations'.format(nlim))
            break
    return x, ni

# Over relaxation method for x = f(x)
def overrelax(f, x = 1., err = 1e-6, nlim = int(1e5), omega = 0.1):
    ni = int(0)
    xold = x + 1.
    while (abs(x - xold) > err):
        xold = x
        x = (1. + omega) * f(x) - omega * x
        ni += 1
        if ni >= int(nlim):
            x = float('inf')
            print('There was no convergence after {} interations'.format(nlim))
            break
    return x, ni

# Bisection method for f(x) = 0
# with scipy:     opt.root_scalar(f, method='bisect', bracket=[a,b])
def bisec(f, a, b, err = 1e-6, nlim = int(1e5)):
    ni = int(0)
    if (a > b):
        a, b = b, a
    while (abs(a - b) > err):
        if (np.sign(f(a)) == 0):    # f(a)=0, I've found the root which is a exactly
            x = a
            break
        if (np.sign(f(b)) == 0):    # f(b)=0, I've found the root which is b exactly
            x = b
            break
        if (np.sign(f(a)) != np.sign(f(b))):
            m = 0.5 * (a + b)
            if (np.sign(f(m)) == 0):
                x = m               # f(m)=0
                break
            if (np.sign(f(m)) == np.sign(f(a))):
                a = m
            else:
                b = m
        else:                       # wrong interval
            x = float('inf')
            print('Wrong chosen interval.')
            break
        ni += 1
        x = 0.5 * (a + b)
        if ni >= int(nlim):
            x = float('inf')
            print('There was no convergence after {} interations'.format(nlim))
            break
    return x, ni

# Newton method + secant methods for f(x) = 0
# with scipy:       opt.root_scalar(f, method='newton', fprime=deriv, x0 = start)
# with scipy:       opt.root_scalar(f, method='secant', x0 = start, x1 = start + 1.)
def newton(f, x, df = None, h = 1e-15, err = 1e-6, nlim = int(1e5)):
    ni = int(0)
    if df != None:              # Newton method
        xold = x + 1.
        while (abs(x - xold) > err):
            xold = x
            x = x - (f(x) / df(x))
            ni += 1
            if ni >= int(nlim):
                x = float('inf')
                print('There was no convergence after {} interations'.format(nlim))
                break
    else:
        xold = x + 1.
        while (abs(x - xold) > err):
            xold = x
            df = (f(x + 0.5 * h) - f(x - 0.5 * h)) / h
            x = x - (f(x) / df)
            ni += 1
            if ni >= int(nlim):
                x = float('inf')
                print('There was no convergence after {} interations'.format(nlim))
                break
    return x, ni

def f1(x, c):
    return 1. - math.exp(-c * x)
def f2(x, c):
    return np.exp(-c * x)
def f3(x):
    return 2. - np.exp(-x) - x

#%%
cmin = 0.
cmax = 3.
cstep = 0.01
results = []
iresults = []
# results = np.array([])
# iresults = np.array([])
for c in np.arange(cmin, cmax, cstep):
    f = lambda x : f1(x, c)
    res, ires = relax(f)
    results.append(res)
    iresults.append(ires)
    # results = np.append(res, results)
    # iresults = np.append(ires, iresults)

plt.plot(np.arange(cmin, cmax, cstep), results)
plt.xlabel('c', size = 16)
plt.ylabel('x(c)', size = 16)
plt.tight_layout()
plt.show()

#%%
x = np.linspace(-2.5, 5., 100)
# for c in np.arange(cmin, cmax, cstep * 10):
#     f = 1. - f2(x, c) - x
#     plt.plot(x, f, '-r')
plt.plot(x, f3(x), '-r')
plt.axhline(ls = '--', c = 'k', lw = 1)
plt.xlim(np.min(x) - 0.1, np.max(x) + 0.1)
plt.tight_layout()
plt.show()