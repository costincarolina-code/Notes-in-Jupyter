# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
from math import factorial as fact

#%%

print('Enter n:')
n = int(input())
    
while n < 0:
    
    print('Please enter positive n.')
    print('Enter n:')
    n = int(input())

sol = np.zeros(n + 1)

for k in range(n + 1):
    
    sol[k] = fact(n) / (fact(k) * (fact(n - k)))
    
print(sol)

#%%

print('Enter number of lines:')
n = int(input())
    
while n < 0:
    
    print('Please enter positive number.')
    print('Enter number of lines:')
    n = int(input())
    
for n in range(n):
    
    sol = np.zeros(n + 1, int)
    for k in range(n + 1):
        
        sol[k] = fact(n) / (fact(k) * (fact(n - k)))
    
    print(sol)
    
#%%

print('Enter number of tosses:')
n = int(input())
print('Enter number of heads:')
k = int(input())

sol = np.zeros(n + 1)

for i in range(n + 1):
    
    sol[i] = fact(n) / (fact(i) * (fact(n - i)))














