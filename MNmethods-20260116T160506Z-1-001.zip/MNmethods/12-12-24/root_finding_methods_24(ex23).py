# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 21:58:37 2024

@author: Nicholas
"""

import numpy as np
from numpy.linalg import norm
import math

err = 1e-6

ecc = np.array([0.1, 0.7, 0.9])
F = np.array([(math.pi / 3.), math.pi])

niter = np.zeros([len(ecc), len(F)], int)
niter_limit = np.zeros([len(ecc), len(F)], int) + 1e3

E = np.zeros([len(ecc), len(F)], float)
Etemp = np.ones([len(ecc), len(F)], float)

#%%%            RELAX
for i in range(len(ecc)):
    for j in range(len(F)):
        while (abs(E[i, j] - Etemp[i, j]) > err) and (niter[i, j] <= niter_limit[i, j]):
            Etemp[i, j] = E[i, j]
            E[i, j] = F[j] + ecc[i] * np.sin(E[i, j])
            niter[i, j] += 1
        if (niter[i, j] == niter_limit[i, j]):
            E[i, j] = np.inf

print(E, '\n', niter)

#%%%            OVERRELAX
omega = 0.1

for i in range(len(ecc)):
    for j in range(len(F)):
        while (abs(E[i, j] - Etemp[i, j]) > err) and (niter[i, j] <= niter_limit[i, j]):
            Etemp[i, j] = E[i, j]
            E[i, j] = (1. + omega) * (F[j] + ecc[i] * np.sin(E[i, j])) - (omega * E[i, j])
            niter[i, j] += 1
        if (niter[i, j] >= niter_limit[i, j]):
            E[i, j] = np.Inf

print(E, '\n', niter)

#%%%            BISECTION
E1 = E + 1.
E2 = E + 4.

for i in range(len(ecc)):
    for j in range(len(F)):
        while (abs(E1[i, j] - E2[i, j]) > err) and (niter[i, j] <= niter_limit[i, j]):
            if np.sign(E1[i, j] - F[j] -  ecc[i] * np.sin(E1[i, j])) == 0:  # f(E1)=0, I've found the root which is E1 exactly
                E[i, j] = E1[i, j]
                break
            if np.sign(E2[i, j] - F[j] -  ecc[i] * np.sin(E2[i, j])) == 0:  # f(E2)=0, I've found the root which is E2 exactly
                E[i, j] = E2[i, j]
                break
            if np.sign(E1[i, j] - F[j] -  ecc[i] * np.sin(E1[i, j])) != np.sign(E2[i, j] - F[j] -  ecc[i] * np.sin(E2[i, j])):
                Emid = 0.5 * (E1[i, j] + E2[i, j])
                if np.sign(Emid - F[j] -  ecc[i] * np.sin(Emid)) == 0:  # f(Emid)=0
                    E[i, j] = Emid
                    break
                if np.sign(Emid - F[j] -  ecc[i] * np.sin(Emid)) == np.sign(E1[i, j] - F[j] -  ecc[i] * np.sin(E1[i, j])):
                    E1[i, j] = Emid
                else:
                    E2[i, j] = Emid
            else:   # wrong interval
                E[i, j] = np.Inf
                print('Wrong chosen interval for ecc =', ecc[i], ', F =', F[j], '.')
                break            
            E[i, j] = 0.5 * (E1[i, j] + E2[i, j])
            niter[i, j] += 1
            
        if (niter[i, j] == niter_limit[i, j]):  # no convergence
            E[i, j] = np.inf
            print('No convergence reached in', niter_limit, 'iterations.')

print(E, '\n', niter)

#%%$            NEWTON-RAPHSON
for i in range(len(ecc)):
    for j in range(len(F)):
        while (abs(E[i, j] - Etemp[i, j]) > err) and (niter[i, j] <= niter_limit[i, j]):
            Etemp[i, j] = E[i, j]
            E[i, j] = E[i, j] - (E[i, j] - F[j] -  ecc[i] * np.sin(E[i, j])) / (1 - ecc[i] * np.cos(E[i, j]))
            niter[i, j] += 1
        if (niter[i, j] == niter_limit[i, j]):
            E[i, j] = np.inf

print(E, '\n', niter)










