#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 14:42:07 2024

@author: frison
"""
import numpy as np
import matplotlib.pyplot as plt
import math
from numpy.fft import rfft, irfft

font = {'family': 'serif',
        'color':  'k',
        'size': 12,
        }
plt.rcParams.update({'font.size': 12})

sampling = 44100
p_piano = '/home/frison/Desktop/NMmethods/piano.txt'
p_trump = '/home/frison/Desktop/NMmethods/trumpet.txt'
piano = np.genfromtxt(p_piano)
trump = np.genfromtxt(p_trump)

#%%
plt.plot(piano)
plt.xlabel('t', size = 16)
plt.ylabel('I', size = 16)
plt.tight_layout()
plt.show()

plt.plot(trump)
plt.xlabel('t', fontdict = font)
plt.ylabel('I', fontdict = font)
plt.tight_layout()
plt.show()

ck_p = rfft(piano)
mck_p = np.abs(ck_p)**2.
ck_t = rfft(trump)
mck_t = np.abs(ck_t)**2.

#%%%
plt.plot(mck_p)
plt.xlim(0, 10000)
plt.yscale('log')
plt.xlabel('$k$', fontdict = font)
plt.ylabel('$C_k^2$', fontdict = font)
plt.title('Piano')
plt.tight_layout()
plt.show()

plt.plot(mck_t)
plt.xlim(0, 10000)
plt.yscale('log')
plt.xlabel('$k$', fontdict = font)
plt.ylabel('$C_k^2$', fontdict = font)
plt.title('Trumpet')
plt.tight_layout()
plt.show()

#%%
note_p = np.argmax(ck_p)
note_t = np.argmax(ck_t)
# freq : len(ck) = real_freq : samp
note_p_real = note_p / len(piano) * sampling
note_t_real = note_t / len(trump) * sampling
print('Piano note: {:.3f} Hz\n Trumpet note: {:.2f} Hz'.format(note_p_real/261, note_t_real/261))



















