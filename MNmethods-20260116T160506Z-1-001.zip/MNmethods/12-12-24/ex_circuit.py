#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 11:46:27 2024

@author: frison
"""
import numpy as np
from numpy.linalg import solve
import math

r1 = float(1e3)
r2 = float(2e3)
r3, r5 = r1, r1
r4, r6 = r2, r2
c1 = float(1e-6)
c2 = 0.5e-6
v = 3.
w = 1000.

A = np.zeros((3, 3), dtype=complex)
Ar = np.array([[1./r1 + 1./r4, 0., 0.], [0., -(1./r2 + 1./r5), 0.], [0., 0., -(1./r3 + 1./r6)]])
Ai = np.array([[w * c1, -(w * c1), 0.], [w * c1, -w * (c1 + c2), (w * c2)], [0., (w * c2), -(w * c2)]])
A = Ar + 1j * Ai
print(A)
b = np.array([v/r1, -v/r2, -v/r3])

ximg = solve(A, b)
print(ximg)
# x = np.absolute(ximg)
# print(x)
