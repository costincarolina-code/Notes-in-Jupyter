#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 11:19:06 2024

@author: frison
"""
import numpy as np
import math
import matplotlib.pyplot as plt

initial_N = int(20)
initial_N = int(20)
font = {'family': 'serif',
        'color':  'k',
        'size': 20,
        }
plt.rcParams.update({'font.size': 17})

# Trapezoidal rule
def trapz(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = 0.5 * (f(a) + f(b))         # first integration
    I1 = 0.
    for i in range(1, int(N)):           # the range goes from start to stop - 1 ! so in this case the for stops at N - 1
        I1 += f(a + i * h)
    Iold = h * (I0 + I1)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2 = 0.
        for i in range(1, N, 2):
            I2 += f(a + i * h)
        Inew = h * (I0 + I1 + I2)
        results.append(Inew)
        err = abs(Inew - Iold) / (3. * abs(Inew))
        errors.append(err)
        I1 = I1 + I2
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break
    
    return Inew#, N

# Simpson rule
def simps(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = f(a) + f(b)             # first integration
    I1o, I1e = 0., 0.
    for i in range(1, int(N)):
        if (i % 2) == 0:
            I1o += f(a + i * h)
        else:
            I1e += f(a + i * h)
    Iold = h / 3. * (I0 + 4. * I1o + 2. * I1e)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2e = I1o + I1e
        I2o = 0.
        for i in range(1, N, 2):
            I2o += f(a + i * h)
        Inew = h / 3. * (I0 + 4. * I2o + 2. * I2e)
        results.append(Inew)
        err = abs(Inew - Iold) / (15. * abs(Inew))
        errors.append(err)
        I1e = I2e
        I1o = I2o
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break

    return Inew#, N

def jm(m, x, t):
    return math.cos(m * t - x * math.sin(t))

#%%             a)
em = np.array([0, 1, 2], dtype = int)
xmin = 0.
xmax = 20.
Np = 1000        # graph points
colors = ['blue', 'red', 'green']
Dtr = np.zeros([len(em), Np])
Dsim = np.zeros([len(em), Np])

k = 1. / math.pi

fig, axs = plt.subplots(1, 2, figsize = (15, 7.5))
for i in range(len(em)):
    m = em[i]
    a = 0.
    j = 0
    for x in np.linspace(xmin, xmax, Np):
        f = lambda t : jm(m, x, t)
        inttr = trapz(f, a, x)
        intsim = simps(f, a, x)
        if j == 0:
            Dtr[i, j] = k * inttr
            Dsim[i, j] = k * intsim
        else:
            Dtr[i, j] = Dtr[i, j - 1] + k * inttr
            Dsim[i, j] = Dsim[i, j - 1] + k * intsim
        a = x
        j += 1
    
    axs[0].plot(np.linspace(xmin, xmax, Np), Dtr[i, :], color = colors[i], label = '$J_{}$'.format(m))
    axs[0].set_xscale('log')
    axs[0].set_xlabel('$a$', fontdict = font)
    axs[0].set_ylabel('$D(a)$', fontdict = font)
    
    axs[1].plot(np.linspace(xmin, xmax, Np), Dsim[i, :], color = colors[i], label = '$J_{}$'.format(m))
    axs[1].set_xscale('log')
    axs[1].set_xlabel('$a$', fontdict = font)
    axs[1].set_ylabel('$D(a)$', fontdict = font)

axs[0].legend(loc = 'upper left')
axs[1].legend(loc = 'upper left')
fig.tight_layout()
plt.show()

#%%             2)
em = np.array([1], dtype = int)
lamb = float(5e-7)
wn = 2 * math.pi / lamb
xmin = 0.
xmax = 20.
Np = 1000        # graph points
colors = ['blue', 'red', 'green']
Dtr = np.zeros([len(em), Np])
Dsim = np.zeros([len(em), Np])

k = 1. / math.pi

fig, axs = plt.subplots(1, 2, figsize = (15, 7.5))
for i in range(len(em)):
    m = em[i]
    a = 0.
    j = 0
    for x in np.linspace(xmin, xmax, Np):
        f = lambda t : jm(m, x, t)
        inttr = trapz(f, a, x)
        intsim = simps(f, a, x)
        if j == 0:
            Dtr[i, j] = k * inttr
            Dsim[i, j] = k * intsim
        else:
            Dtr[i, j] = Dtr[i, j - 1] + k * inttr
            Dsim[i, j] = Dsim[i, j - 1] + k * intsim
        a = x
        j += 1
    
    axs[0].plot(np.linspace(xmin, xmax, Np), Dtr[i, :], color = colors[i], label = '$J_{}$'.format(m))
    axs[0].set_xscale('log')
    axs[0].set_xlabel('$a$', fontdict = font)
    axs[0].set_ylabel('$D(a)$', fontdict = font)
    
    axs[1].plot(np.linspace(xmin, xmax, Np), Dsim[i, :], color = colors[i], label = '$J_{}$'.format(m))
    axs[1].set_xscale('log')
    axs[1].set_xlabel('$a$', fontdict = font)
    axs[1].set_ylabel('$D(a)$', fontdict = font)

axs[0].legend(loc = 'upper left')
axs[1].legend(loc = 'upper left')
fig.tight_layout()
plt.show()
























