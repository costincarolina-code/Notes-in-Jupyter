#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 15:51:44 2024

@author: frison
"""
import numpy as np

def V_n_dim_sph(n, N = 10000, r = 1.):
    while True:
        if n <= 1:
            print('Please input proper n-dimensions.')
            break
        else:  
            if r == 1.:
                xa, xb = 0., 2.
            else:
                xa, xb = 0., 2. * r
            
            V = xb ** n
            coord = np.zeros([n, N])
            coordp2 = np.zeros([n, N])
            for i in range(n):
                coord[i, :] = np.random.uniform(xa, xb, N)
                coordp2[i, :] = coord[i, :]**2.
    