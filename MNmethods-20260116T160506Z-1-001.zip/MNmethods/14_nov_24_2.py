#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 11:33:24 2024

@author: frison
"""
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.optimize as opt
import scipy.constants as const

initial_N = int(20)
font = {'family': 'serif',
        'color':  'k',
        'size': 20,
        }
plt.rcParams.update({'font.size': 17})

def trapz(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = 0.5 * (f(a) + f(b))         # first integration
    I1 = 0.
    for i in range(1, int(N)):           # the range goes from start to stop - 1 ! so in this case the for stops at N - 1
        I1 += f(a + i * h)
    Iold = h * (I0 + I1)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2 = 0.
        for i in range(1, N, 2):
            I2 += f(a + i * h)
        Inew = h * (I0 + I1 + I2)
        results.append(Inew)
        err = abs(Inew - Iold) / (3. * abs(Inew))
        errors.append(err)
        I1 = I1 + I2
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break
    
    return Inew#, err, iteration, results, errors, en

def simps(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = f(a) + f(b)             # first integration
    I1o, I1e = 0., 0.
    for i in range(1, int(N)):
        if (i % 2) == 0:
            I1o += f(a + i * h)
        else:
            I1e += f(a + i * h)
    Iold = h / 3. * (I0 + 4. * I1o + 2. * I1e)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2e = I1o + I1e
        I2o = 0.
        for i in range(1, N, 2):
            I2o += f(a + i * h)
        Inew = h / 3. * (I0 + 4. * I2o + 2. * I2e)
        results.append(Inew)
        err = abs(Inew - Iold) / (15. * abs(Inew))
        errors.append(err)
        I1e = I2e
        I1o = I2o
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break

    return Inew#, err, iteration, results, errors, en

def H(x):
    return H0 * np.sqrt(wl + wm / x**3.)

def f(x):
    if x < 1e-30:
        return 0.
    else:
        return (H0 / (x * H(x)))**3.

#%%
wms = np.array([0.1, 0.3, 0.6, 1])
H0 = 67.4       # km s-1 Mpc-1
amin = 0.1
amax = 2.
Np = 300        # graph points
colors = ['blue', 'darkviolet', 'red', 'green']
Dtr = np.zeros([len(wms), Np])
Dsim = np.zeros([len(wms), Np])

fig, axs = plt.subplots(1, 2, figsize = (15, 7.5))
for i in range(len(wms)):
    wm = wms[i]
    wl = 1. - wm
    a = 0.
    j = 0
    for b in np.linspace(amin, amax, Np):
        inttr = trapz(f, a, b)
        intsim = simps(f, a, b)
        k = 5 * wm * H(b) / 2. / H0
        if j == 0:
            Dtr[i, j] = k * inttr
            Dsim[i, j] = k * intsim
        else:
            Dtr[i, j] = Dtr[i, j - 1] + k * inttr
            Dsim[i, j] = Dsim[i, j - 1] + k * intsim
        a = b
        j += 1
    
    axs[0].plot(np.linspace(amin, amax, Np), Dtr[i, :], color = colors[i], label = '$\Omega_m = {}$'.format(wms[i]))
    axs[0].set_xscale('log')
    axs[0].set_xlabel('$a$', fontdict = font)
    axs[0].set_ylabel('$D(a)$', fontdict = font)
    
    axs[1].plot(np.linspace(amin, amax, Np), Dsim[i, :], color = colors[i], label = '$\Omega_m = {}$'.format(wms[i]))
    axs[1].set_xscale('log')
    axs[1].set_xlabel('$a$', fontdict = font)
    axs[1].set_ylabel('$D(a)$', fontdict = font)

axs[0].legend(loc = 'upper left')
axs[1].legend(loc = 'upper left')
fig.tight_layout()
plt.show()

#%%
def simps(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = f(a) + f(b)             # first integration
    I1o, I1e = 0., 0.
    for i in range(1, int(N)):
        if (i % 2) == 0:
            I1o += f(a + i * h)
        else:
            I1e += f(a + i * h)
    Iold = h / 3. * (I0 + 4. * I1o + 2. * I1e)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2e = I1o + I1e
        I2o = 0.
        for i in range(1, N, 2):
            I2o += f(a + i * h)
        Inew = h / 3. * (I0 + 4. * I2o + 2. * I2e)
        results.append(Inew)
        err = abs(Inew - Iold) / (15. * abs(Inew))
        errors.append(err)
        I1e = I2e
        I1o = I2o
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break

    return Inew, N

def H(x):
    return H0 * np.sqrt(wl + wm / x**3.)

def f(x):
    if x < 1e-30:
        return 0.
    else:
        return (H0 / (x * H(x)))**3.

wms = np.array([0.1, 0.3, 0.6, 1])
H0 = 67.4       # km s-1 Mpc-1
D = np.zeros([len(wms)])
N = np.zeros([len(wms)])
for i in range(len(wms)):
    wm = wms[i]
    wl = 1. - wm
    k = 5 * wm * H(b) / 2. / H0
    D[i], N[i] = simps(f, 0., 0.5, N = 10, tol = 1e-12)

print(D, '\n', N)














