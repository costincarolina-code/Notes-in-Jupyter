# -*- coding: utf-8 -*-
"""
Created on Sat Mar 30 00:31:50 2024

@author: Nicholas
"""
import matplotlib.pyplot as plt

# font for plots
font = {'family': 'serif',
        'color':  'k',
        'size': 12,
        }
plt.xlabel('x', fontdict = font)
plt.rcParams.update({'font.size': 17})

# subplots
fig, axs = plt.subplots(2, 3)

fig.tight_layout()
plt.show()

# vertical and orizontal lines

plt.axvline(ls = 'dashed', color = 'r', lw = 1)
plt.axhline(ls = 'dashed', color = 'r', lw = 1)