# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 11:00:04 2024

@author: Nicholas
"""

import numpy as np
import math
import matplotlib.pyplot as plt

def f(a, e):
    
    fa = - 64. * G**3. * m1 * m2 * (m1 + m2) / (5. * c**5. * a**3. * (1 - e**2.)**3.5) * (1. + 73. * e**2. / 24 + 37. * e**4. / 96.)
    fe = - 304. * e * G**3. * m1 * m2 * (m1 + m2) / (15. * c**5. * a**4. * (1 - e**2.)**2.5) * (1. + 121. * e**2. / 304.)
    
    return fa, fe

def rk1(a, e, h):
    
    fa, fe = f(a, e)
    at = a + h * fa
    et = e + h * fe
    
    return at, et
    
#%%%
m1 = 30.    # Msum
m2 = 30.    # Msum
a0 = 1.     # AU
e0 = 0.7

G = 4. * math.pi**2.    # AU^3 yr^-2 Msun^-1
c = 63197.8     # AU yr^-1

rsch = 2. * G * (m1 + m2) / c**2.   # AU
also = 3. * rsch

a = np.array([])
a = np.append(a, a0)
e = np.array([])
e = np.append(e, e0)
t = np.array([])
t = np.append(t, 0.)

i = int(0)
imax = int(1e5)

tol = 1e-2
h = 1e3


while ((abs(a[i] - also) / also > 1e-1) and i < imax):
    
    atemp, etemp = rk1(a[i], e[i], h)           # a and e at t+h
    
    if (abs(atemp - a[i]) / a[i] < 0.1 * tol):  # recalculate for adaptive h 
        h = 2. * h
        atemp, etemp = rk1(a[i], e[i], h)
    
    elif (abs(atemp - a[i]) / a[i] > tol):
        while (abs(atemp - a[i]) / a[i] > tol):
            h = h / 10.
            atemp, etemp = rk1(a[i], e[i], h)
    
    ttemp = t[i] + h
    a = np.append(a, atemp)
    e = np.append(e, etemp)
    t = np.append(t, ttemp)
    i += 1

fig, axs = plt.subplots(2, 1)

axs[0].plot(t, a, 'b-')
axs[0].set_xscale('log')
axs[0].set_ylabel('$\mathrm{a [AU]}$')

axs[1].plot(t, e, 'g-')
axs[1].set_xscale('log')
axs[1].set_xlabel('$\mathrm{time [yr]}$')
axs[1].set_ylabel('$\mathrm{e}$')

fig.tight_layout()
plt.show()
