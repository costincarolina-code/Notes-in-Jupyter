#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 11:12:25 2024

@author: frison
"""
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.optimize as opt
import scipy.constants as const

# Bisection method for f(x) = 0
# with scipy:     opt.root_scalar(f, method='bisect', bracket=[a,b])
def bisec(f, a, b, err = 1e-6, nlim = int(1e5)):
    ni = int(0)
    if (a > b):
        a, b = b, a
    while (abs(a - b) > err):
        if (np.sign(f(a)) == 0):    # f(a)=0, I've found the root which is a exactly
            x = a
            break
        if (np.sign(f(b)) == 0):    # f(b)=0, I've found the root which is b exactly
            x = b
            break
        if (np.sign(f(a)) != np.sign(f(b))):
            m = 0.5 * (a + b)
            if (np.sign(f(m)) == 0):
                x = m               # f(m)=0
                break
            if (np.sign(f(m)) == np.sign(f(a))):
                a = m
            else:
                b = m
        else:                       # wrong interval
            x = float('inf')
            print('Wrong chosen interval.')
            break
        ni += 1
        x = 0.5 * (a + b)
        if ni >= int(nlim):
            x = float('inf')
            print('There was no convergence after {} interations'.format(nlim))
            break
    return x, ni

def f(x):
    return 5 * np.exp(-x) + x - 5

#%%
lamb = 502e-9
h = const.h
c = const.c
kb = const.k
# h = 6.6261e-34
# c = 2.998e8
# kb = 1.381e-23
x, ni = bisec(f, 4., 6.)
# root1 = opt.root_scalar(f, method='bisect', bracket=[4., 6.])
# print(root, root1.root)

b = (h * c) / (kb * x)
# b1 = (h * c) / (kb * root1.root)
T = b / lamb
wl = b / T
# wl1 = b1 / T
# print(wl, wl1)
print('The root wavelenght is {0} m (x = {1:.3f}) corresponding to a temperature of {2:.2f} K. This was found after {3} iterations'.format(wl, x, T, ni))

#%%
x = np.linspace(-1, 7., 100)
plt.plot(x, f(x), '-r')
plt.axhline(ls = '--', c = 'k', lw = 1)
plt.xlim(np.min(x) - 0.1, np.max(x) + 0.1)
plt.tight_layout()
plt.show()
