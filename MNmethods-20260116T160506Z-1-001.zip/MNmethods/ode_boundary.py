# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 17:19:59 2024

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt

def f(v):
    
    fx = v
    fv = -g
    
    return fx, fv

def rk1(x, v, t0, tf, h):
    
    t = t0
    
    while (t < tf):
        fx, fv = f(v)
        x = x + h * fx
        v = v + h * fv
        t += h
    
    return x, v

def rk1n(x, v, t0, tf, h):      # saving numpy arrays
    
    t = t0
    xt = np.array([])
    xt = np.append(xt, x)       # append x0
    vt = np.array([])
    vt = np.append(vt, v)       # append v0
    
    while (t < tf):
        fx, fv = f(v)
        x = x + h * fx
        v = v + h * fv
        xt = np.append(xt, x)
        vt = np.append(vt, v)
        t += h
    
    return xt, vt

#%%%
g = 9.81    # m s^-2

x0 = 0.
xf = 10.
t0 = 0.
tf = 3.
v01 = 15.
v02 = 20.

N = int(1e3)
tol = 1e-8
imax = 1e5

h = (tf - t0) / N
x = x0
i = int(0)

while ((abs(x - xf) > tol) and (i < imax)):
    xt1, vt1 = rk1(x0, v01, t0, tf, h)
    xt2, vt2 = rk1(x0, v02, t0, tf, h)
    
    if (i == 0) and ((xt1 > xf) or (xt2 < xf)):
        x = float('nan')
        v = float('nan')
        if (xt1 > xf):
            print('Chose smaller lower bound.')
            break
        if (xt2 < xf):
            print('Chose bigger upper bound.')
            break
        
    v0mid = 0.5 * (v01 + v02)
    xtmid, vtmid = rk1(x0, v0mid, t0, tf, h)
    
    if (xtmid > xf):
        v02 = v0mid
        x = 0.5 * (xt1 + xtmid)
        v = 0.5 * (v01 + v02)
    
    if (xtmid < xf):
        v01 = v0mid
        x = 0.5 * (xt2 + xtmid)
        v = 0.5 * (v01 + v02)
    
    i += 1

xt, vt = rk1n(x0, v, t0, tf, h)
t = np.arange(t0, tf + h, h)

plt.plot(t, xt, 'b-', label = '$\mathrm{x(t)}$')
plt.plot(t, vt, 'r-', label = '$\mathrm{v(t)}$')
plt.xlabel('$\mathrm{t(s)}$')
plt.legend(loc = 'lower left')

plt.tight_layout()
plt.show()

















