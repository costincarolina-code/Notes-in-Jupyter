# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 16:30:39 2025

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt
import numpy.random as rnd
import math
from scipy.integrate import simpson as simp
from scipy.integrate import odeint as ode

#%%             EXERCISE 1
def p(x):
    return a * np.exp(-a * x)
def w(x):
    return np.exp(-a * x)
def intp(x):
    return -1. / a * np.log(1. - x)
def intw(x):
    return -1. / a * np.log(1. - a * x)
def integrand(x):
    return np.array((1. / (x**2. + np.cos(x)**2.)))

#%%         Q1
N = int(1e5)
a = 0.6

x = rnd.uniform(size = N)
y = intp(x)

#%%         Q2
x = np.linspace(0., np.max(y), 100)
plt.hist(y, bins = 100, density = True, ec = 'black')
plt.plot(x, p(x), '-', c = 'darkorange', label = 'p(x) with a = 0.6')
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%         Q3
x = np.linspace(0., math.pi, 1000)
plt.plot(x, integrand(x), '-k', label = 'Integrand')
plt.plot(x, w(x), '-r', label = 'w(x)')
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%         Q4
N = int(1e5)
a = 0.6
m = rnd.uniform(size = N)
y = intp(m)
# x = np.linspace(0., np.max(y), 100)
# plt.hist(y, bins = 100, density = True, ec = 'black')
# plt.plot(x, w(x), '-', c = 'darkorange', label = 'w(x)')
# plt.legend(loc = 'upper right')
# plt.tight_layout()
# plt.show()
I = 1. / N * np.sum(integrand(y) / w(y)) * (1. / a * (1. - math.exp(-a * math.pi)))
print(I)

#%%         Q5
grid = np.linspace(0., math.pi, N)
y = integrand(grid)
Isimp = simp(y, grid)
print('Result from importance sampling: {0:.3f} \nResult from Simpson integration: {1:.3f}'.format(I, Isimp))

#%%             EXERCISE 2
#%%         Q1
def vel(x, y):
    v = 2.
    modv = np.sqrt((x[1] - x[0])**2. + (y[1] - y[0])**2.)
    vx = v * (x[1] - x[0]) / modv
    vy = v * (y[1] - y[0]) / modv
    return vx, vy

#%%         Q2
def ex2(initial_cond, t):
    def f(x, t):
        f6 = x[0]
        f7 = x[1]
        f8 = x[2]
        f9 = x[3]
        f10 = x[4]
        f11 = x[5]
        f0, f1 = vel([f6, f8], [f7, f9])
        f2, f3 = vel([f8, f10], [f9, f11])
        f4, f5 = vel([f10, f6], [f11, f7])
        return np.array([f0, f1, f2, f3, f4, f5])

    sol = ode(f, initial_cond, t)
    return sol

t0 = 0.
t1 = 1.
dt = 0.01
t = np.arange(t0, t1, dt)
A = [0., 0.]
B = [3., 0.]
C = [1.5, 1.5 * np.sqrt(3)]

initial_cond = np.concatenate((A, B, C))
solq2 = ex2(initial_cond, t)

#%%         Q3
N = 1000
x = np.linspace(0., 3., N)
y = np.zeros(N)
x1 = np.linspace(0., 1.5, N)
y1 = np.sqrt(3) * x1
x2 = np.linspace(1.5, 3., N)
y2 = -np.sqrt(3) * x2 + 3. * np.sqrt(3)
plt.plot(solq2[:, 0], solq2[:, 1], label = 'Particle A')
plt.plot(solq2[:, 2], solq2[:, 3], label = 'Particle B')
plt.plot(solq2[:, 4], solq2[:, 5], label = 'Particle C')
plt.plot(x, y, '-k')
plt.plot(x1, y1, '-k')
plt.plot(x2, y2, '-k')
plt.plot()
plt.plot()
plt.xlabel('x')
plt.ylabel('y')
plt.title('Motion of the 3 particles')
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()







