#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 10:47:04 2024

@author: frison
"""

import numpy as np
import math
import matplotlib.pyplot as plt

initial_N = int(20)
# Trapezoidal rule
# with scipy.integrate.trapezoid(integrand, grid)
def trapz(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = 0.5 * (f(a) + f(b))         # first integration
    I1 = 0.
    for i in range(1, N):           # the range goes from start to stop - 1 ! so in this case the for stops at N - 1
        I1 += f(a + i * h)
    Iold = h * (I0 + I1)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2 = 0.
        for i in range(1, N, 2):
            I2 += f(a + i * h)
        Inew = h * (I0 + I1 + I2)
        results.append(Inew)
        err = abs(Inew - Iold) / (3. * abs(Inew))
        errors.append(err)
        I1 = I1 + I2
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break
    
    return Inew, err, iteration, results, errors, en

# Simpson rule
# with scipy.integrate.simpson(integrand, grid)
def simps(f, a, b, N = initial_N, tol = 1e-7):
    err = 1.
    results = []
    errors = []
    errors.append(err)
    en = []
    en.append(N)
    iteration = 0
    
    h = (b - a) / N
    I0 = f(a) + f(b)             # first integration
    I1o, I1e = 0., 0.
    for i in range(1, int(N)):
        if (i % 2) == 0:
            I1o += f(a + i * h)
        else:
            I1e += f(a + i * h)
    Iold = h / 3. * (I0 + 4. * I1o + 2. * I1e)
    results.append(Iold)
    
    while(err >= tol):
        N = int(2 * N)
        en.append(N)
        h = (b - a) / N
        I2e = I1o + I1e
        I2o = 0.
        for i in range(1, N, 2):
            I2o += f(a + i * h)
        Inew = h / 3. * (I0 + 4. * I2o + 2. * I2e)
        results.append(Inew)
        err = abs(Inew - Iold) / (15. * abs(Inew))
        errors.append(err)
        I1e = I2e
        I1o = I2o
        Iold = Inew
        
        iteration += 1
        
        if N > 1e7:
            print('The required accuracy could not be reached within', round(N), 'points. \n')
            print('Stopping at N = {0} with accuracy = {1:.3e}'.format(N, err))
            break

    return Inew, err, iteration, results, errors, en

# Romberg
# import scipy.integrate as integrate
# integrate.romberg(integrand, start, finish)
# you can use: integrade.quad

def f(x):
    return math.exp(x)      # expected 145.69
def sis(x):
    return 2. * sigma2 / G # msum pc^-1
def nfw(x):
    return 4. * math.pi * x * rho0 * rs / (1. + x / rs)**2.

G = 4.3009e-3 # pc km^2 s^-2 msum^-1
#%%
a = 1.
b = 5.
N = 100

Itr, etr, itr, rest, et, ent = trapz(f, a, b)
Isim, esim, isim, ress, es, ens = simps(f, a, b)

print('The result of the integration between {0} and {1} is {2:.3e} with an error of {3:.3e}, this was done with {4} iterations.'.format(a, b, Itr, etr, itr))
print('\nThe result of the integration between {0} and {1} is {2:.3e} with an error of {3:.3e}, this was done with {4} iterations.'.format(a, b, Isim, esim, isim))

print(rest, '\n', et, '\n', ress, '\n', es)

#%%             singular isothermal sphere
sigma = 10. # km/s
sigma2 = sigma**2.

rmin = 0.
rmax = 10. # pc

N = 100
tol = 1e-6

Itr, etr, itr, rest, et, ent = trapz(sis, rmin, rmax, N, tol)
Isim, esim, isim, ress, es, ens = simps(sis, rmin, rmax, N, tol)

print('TRAPEZOIDAL: The resulting mass using a Singluar Isothermal Sphere is {0:.3e} solar masses, with error {1:.3e}. This took {2} iterations.'.format(Itr, etr, itr))
print('\nSIMPSON: The resulting mass using a Singluar Isothermal Sphere is {0:.3e} solar masses, with error {1:.3e}. This took {2} iterations.'.format(Isim, esim, isim))

print(rest, '\n', et, '\n', ress, '\n', es)

#%%             navarro frenk white
rho0 = float(1e8) # msum kpc^-3
rho0 = rho0 / 1e9 # pc
rs = 10. # kpc
rs = rs * 1e3 # pc

rmin = 0.
rmax = 100. * rs # pc

N = 100
tol = 1e-6

Itr, etr, itr, rest, et, ent = trapz(nfw, rmin, rmax, N, tol)
Isim, esim, isim, ress, es, ens = simps(nfw, rmin, rmax, N, tol)

print('TRAPEZOIDAL: The resulting mass using NFW profile is {0:.3e} solar masses, with error {1:.3e}. This took {2} iterations.'.format(Itr, etr, itr))
print('\nSIMPSON: The resulting mass using NFW profile is {0:.3e} solar masses, with error {1:.3e}. This took {2} iterations.'.format(Isim, esim, isim))

print(rest, '\n', et, '\n', ress, '\n', es)















