# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 23:18:13 2025

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt
import numpy.random as rnd
import numpy.fft as fft
from scipy.integrate import odeint as ode

#%%             Q1.1

def s(t):
    return np.sin(0.01 * t) + 3. * np.cos(0.03 * t)
def d(t, sigma):
    return s(t) + rnd.normal(scale = sigma, size = len(s(t)))

N = 10
t0 = 0.
tf = 1000.
dt = 1.
smp_size = int(tf / dt)
sigma = 2.
t = np.arange(t0, tf, dt)

sol1 = d(t, sigma)
plt.plot(t, sol1, '-r', label = r'$d_i$', lw = 1)
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$d_i$', size = 16)
plt.title('Data with gaussian noise of sigma = {}'.format(sigma), size = 16)
plt.tight_layout()
plt.show()

#%%             Q1.2

sol2 = np.empty((smp_size, N), float)
for i in range(N):
    sol2[:, i] = d(t, sigma)
    plt.plot(t, sol2[:, i], label = r'$d_{}$'.format(i), lw = 1)

aver_sol2 = np.average(sol2, axis = 1)
plt.plot(t, aver_sol2, '-k', label = 'Average', lw = 2)
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$d_i$', size = 16)
plt.title('10 data sets', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q1.3

def gauss_window(sigma, smp_size):
    def gauss(x, sigma):
        norm = 1. / (2. * sigma**2.)
        f = norm * np.exp(-(x**2) / (2. * sigma**2))
        return f
    gauss = np.vectorize(gauss)
    x = np.arange(0., smp_size + 1., 1.)
    W = gauss(x, sigma) + gauss(x - smp_size, sigma)
    return W

data = d(t, sigma)
ck_data = fft.rfft(data)

W = gauss_window(sigma, smp_size)
ck_W = fft.rfft(W)

ck_filtered = ck_data * ck_W
data_filtr = fft.irfft(ck_filtered)

plt.plot(t, data, label = 'Data', lw = 1)
plt.plot(t, data_filtr, '-k', label = 'Filtered data') 
plt.xlabel('t', size=16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q2.1

def rk4(f, t0, tf, h, x0):
    
    N = int((tf - t0) / h)

    xt = np.zeros(N, float)
    t = np.arange(t0, tf, h)
    xt = np.zeros((N, x0.size), float)
    xt[0, :] = x0
    
    for i in range(1, len(xt)):
        k1 = 0.5 * h * f(xt[i - 1], t[i - 1])
        k2 = 0.5 * h * f(xt[i - 1] + k1, t[i - 1] + 0.5 * h)
        k3 = h * f(xt[i - 1] + k2, t[i - 1] + 0.5 * h)
        k4 = h * f(xt[i - 1] + k3, t[i - 1] + h)
        xt[i] = xt[i - 1] + (2. * k1 + 4. * k2 + 2. * k3 + k4) / 6.
    return xt

def f(x, t):
    f0 = alpha * x[1]
    f1 = x[0] * (1. - x[1])
    return np.array([f0, f1])

def xrate_cost(x):
    D = x[:, 0]
    E = x[:, 1]
    W = 1. / (1. - E)
    R = D / W
    C = beta * D / R
    return R, C

D0 = 0.1
E0 = 0.
alpha = 2.
beta = 0.01
t0 = 0.
tf = 5.
dt = 0.01
x0 = np.array([D0, E0])

sol = rk4(f, t0, tf, dt, x0)

R, C = xrate_cost(sol)
t = np.arange(t0, tf, dt)

plt.plot(t, sol[:, 0], '-r')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$D(t)$', size = 16)
plt.title('Demand', size = 16)
plt.tight_layout()
plt.show()

plt.plot(t, sol[:, 1], '-r')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$R(t)$', size = 16)
plt.title('Amount extracted', size = 16)
plt.tight_layout()
plt.show()

plt.plot(t, R, '-r')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$R(t)$', size = 16)
plt.title('Extraction rate', size = 16)
plt.tight_layout()
plt.show()

plt.plot(t, C, '-r')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$C(t)$', size = 16)
plt.title('Cost', size = 16)
plt.tight_layout()
plt.show()





