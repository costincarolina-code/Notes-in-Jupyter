# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 16:44:44 2025

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt
import numpy.random as rnd
from scipy.integrate import odeint as ode

#%%             Q1.1

def p(t):
    return 1. - 2.**(-t / tau)

tau = 3.053 * 60.   # sec
t0 = 0
tf = 3000
dt = 1
N = 1000

Tl208 = rnd.uniform(size = N)
counts = []
decay = np.zeros(N)

for t in range(t0, tf, dt):
    prob = p(t)
    Tl208 = np.where(Tl208 < prob, np.inf, Tl208)
    decay = np.where(Tl208 == np.inf, 1, decay)
    counts.append(N - np.count_nonzero(decay))

t = np.arange(t0, tf, dt)

plt.plot(t, counts, '-r')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$N$', size = 16)
plt.title('Decay of {} Thallium 208 isotopes'.format(N), size = 16)
plt.tight_layout()
plt.show()

#%%             Q1.2

def P(t, a):
    return a * np.exp(-a * t)
def intp(t, a):
    return -1. / a * np.log(1. - t)

tau = 3.053 * 60.   # sec
t0 = 0
tf = 3000
dt = 1
N = 1000
a = np.log(2.) / tau

x = rnd.uniform(size = N)
y = intp(x, a)

y = np.sort(y)
counts = []
decay = np.zeros(N)

for t in range(t0, tf, dt):
    decay = np.where(y < t, 1, decay)
    counts.append(N - np.count_nonzero(decay))

t = np.arange(t0, tf, dt)

plt.plot(t, counts, '-b')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$N$', size = 16)
plt.title('Decay of {} Thallium 208 isotopes'.format(N), size = 16)
plt.tight_layout()
plt.show()

#%%             Q2.1

def CMR(initial_cond, t, b, beta):
    def f(x, t):
        f0 = x[2]
        f1 = x[3]
        f2 = beta * np.sin(x[1] - x[0]) - b * x[2]
        f3 = beta * np.sin(x[0] - x[1]) - b * x[3]
        return np.array([f0, f1, f2, f3])
    
    sol = ode(f, initial_cond, t)
    return sol

b = 0.1
beta = 5.
t0 = 0.
tf = 40
N = int(1e4)
init1 = np.array([0., 0., 1. , -1.])
init2 = np.array([0., 0., 7. , -3.])
t = np.linspace(t0, tf, N)

sol1 = CMR(init1, t, b, beta)
sol2 = CMR(init2, t, b, beta)

#%%             Q2.2

plt.plot(t, sol1[:, 0], label = r'$\Theta_1(t)$')
plt.plot(t, sol1[:, 1], label = r'$\Theta_2(t)$')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$\Theta$', size = 16)
plt.title(r'Solutions for $\dot{\Theta_1} = 1, \dot{\Theta_2} = -1,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t, sol2[:, 0], label = r'$\Theta_1(t)$')
plt.plot(t, sol2[:, 1], label = r'$\Theta_2(t)$')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$\Theta$', size = 16)
plt.title(r'Solutions for $\dot{\Theta_1} = 7, \dot{\Theta_2} = -3,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t, sol1[:, 2], label = r'$\dot{\Theta_1(t)}$')
plt.plot(t, sol1[:, 3], label = r'$\dot{\Theta_2(t)}$')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$\dot{\Theta}$', size = 16)
plt.title(r'Solutions for $\dot{\Theta_1} = 1, \dot{\Theta_2} = -1,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t, sol2[:, 2], label = r'$\dot{\Theta_1(t)}$')
plt.plot(t, sol2[:, 3], label = r'$\dot{\Theta_2(t)}$')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$\dot{\Theta}$', size = 16)
plt.title(r'Solutions for $\dot{\Theta_1} = 7, \dot{\Theta_2} = -3,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(sol1[:, 0], sol1[:, 2], label = r'$\dot{\Theta_1(\Theta_1)}$')
plt.xlabel(r'$\Theta$', size = 16)
plt.ylabel(r'$\dot{\Theta}$', size = 16)
plt.title('Phase diagram for $\dot{\Theta_1} = 1, \dot{\Theta_2} = -1,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(sol2[:, 0], sol2[:, 2], label = r'$\dot{\Theta_1(\Theta_1)}$')
plt.xlabel(r'$\Theta$', size = 16)
plt.ylabel(r'$\dot{\Theta}$', size = 16)
plt.title('Phase diagram for $\dot{\Theta_1} = 7, \dot{\Theta_2} = -3,$', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()



