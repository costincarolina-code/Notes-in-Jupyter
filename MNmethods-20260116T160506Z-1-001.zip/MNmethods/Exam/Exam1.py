# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 23:37:27 2025

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.optimize as opt
from scipy.integrate import odeint as ode

#%%                     EXERCISE 1
def f1(E):
    return math.tan(math.sqrt(0.5 * w2 * m * E / h2))
def f2(E):
    return math.sqrt((V - E)/E)
def f3(E):
    return -1. * math.sqrt(E/(V - E))
def Ene(E):         # even En
    return math.tan(math.sqrt(0.5 * w2 * m * E / h2)) - math.sqrt((V - E)/E)
def Eno(E):         # odd En
    return math.tan(math.sqrt(0.5 * w2 * m * E / h2)) + math.sqrt(E/(V - E))

c = float(3e8)      # speed of light (m/s)
c2 = c**2.
m = 0.51e6 / c2     # eletron mass (eV)
h = 6.582e-16       # plank constant (eV s)
h2 = h**2.
V = 20.             # potential height (ev)
w = float(1e-9)     # potential width (m)
w2 = w**2.

E = np.linspace(0.1, 6., 1000)

y1, y2, y3 = np.zeros(len(E)), np.zeros(len(E)), np.zeros(len(E))

for i in range(len(E)):
    y1[i] = f1(E[i])
    y2[i] = f2(E[i])
    y3[i] = f3(E[i])

y1[:-1][np.diff(y1) < 0] = np.nan
plt.plot(E, y1, '-r', label = 'Tangent function')
plt.plot(E, y2, '-b', label = 'Even functions')
plt.plot(E, y3, '-g', label = 'Odd functions')
plt.xlabel('Energy', size = 16)
plt.legend(loc = 'upper left')
# plt.yscale('log')
# plt.xlim(0, 3)
plt.ylim(-20., 20.)
plt.tight_layout()
plt.show()

E0 = opt.root_scalar(Ene, method='secant', x0 = 0.3)
E1 = opt.root_scalar(Eno, method='secant', x0 = 0.4)
E2 = opt.root_scalar(Ene, method='secant', x0 = 0.4)
E3 = opt.root_scalar(Eno, method='secant', x0 = 5.)

print('E0 = {0:.3f}, E1 = {1:.3f}, E2 = {2:.3f}, E3 = {3:.3f}'.format(E0.root, E1.root, E2.root, E3.root))


#%%                     EXERCISE 2
def osc(initial_cond, t, mu, wu):
    def f(x, t):
        f0 = x[1]
        f1 = mu * (1 - x[0]**2.)* x[1] - wu**2. * x[0]
        return np.array([f0, f1])

    init = np.array([initial_cond[0], initial_cond[1]])
    sol = ode(f, init, t)
    return sol
# q1:
t = np.linspace(0., 100., 10000)
initial_cond = [1., 0.]
mu = 0.1
wu = 1.
sol1 = osc(initial_cond, t, mu, wu)

plt.plot(t, sol1[:, 0], label = 'x(t)')
plt.plot(t, sol1[:, 1], label = 'v(t)')
plt.xlabel('t', size = 16)
plt.legend(loc = 'lower left')
plt.tight_layout()
plt.show()

# q2:
plt.plot(sol1[:, 0], sol1[:, 1])
plt.xlabel('x(t)', size = 16)
plt.ylabel('v(t)', size = 16)
plt.title('Phase Diagram', size = 16)
plt.tight_layout()
plt.show()

# q3:
t = np.linspace(0., 100., 10000)
initial_cond = [3., 2.]
mu = 0.1
wu = 1.
sol2 = osc(initial_cond, t, mu, wu)

plt.plot(t, sol1[:, 0], label = 'Old x(t)')
plt.plot(t, sol1[:, 1], label = 'Old v(t)')
plt.plot(t, sol2[:, 0], label = 'x(t)')
plt.plot(t, sol2[:, 1], label = 'v(t)')
plt.xlabel('t', size = 16)
plt.legend(loc = 'lower left')
plt.tight_layout()
plt.show()

plt.plot(sol1[:, 0], sol1[:, 1], label = 'Old solution')
plt.plot(sol2[:, 0], sol2[:, 1], label = 'New solution')
plt.xlabel('x(t)', size = 16)
plt.ylabel('v(t)', size = 16)
plt.title('Phase Diagram', size = 16)
plt.tight_layout()
plt.show()

# q4:
t = np.linspace(0., 100., 10000)
initial_cond = [1., 0.]
mu = 10
wu = 1.
sol3 = osc(initial_cond, t, mu, wu)

plt.plot(t, sol2[:, 0], label = 'Old x(t)')
plt.plot(t, sol2[:, 1], label = 'Old v(t)')
plt.plot(t, sol3[:, 0], label = 'x(t)')
plt.plot(t, sol3[:, 1], label = 'v(t)')
plt.xlabel('t', size = 16)
plt.legend(loc = 'lower left')
plt.tight_layout()
plt.show()

plt.plot(sol2[:, 0], sol2[:, 1], label = 'Old solution')
plt.plot(sol3[:, 0], sol3[:, 1], label = 'New solution')
plt.xlabel('x(t)', size = 16)
plt.ylabel('v(t)', size = 16)
plt.title('Phase Diagram', size = 16)
plt.tight_layout()
plt.show()






