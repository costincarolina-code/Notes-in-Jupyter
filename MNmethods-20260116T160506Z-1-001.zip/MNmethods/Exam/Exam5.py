# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 17:30:38 2025

@author: Nicholas
"""

import numpy as np
import matplotlib.pyplot as plt
import numpy.fft as fft

#%%             Q1.1
def osc(initial_cond, t, p, Fext = False):
    def f(x, t):
        if Fext == False:
            dV2 = 0.
        else:
            dV2 = F0 * np.sin(omega * t)
        dV1 = k * x[0]**(p - 1.)
        f0 = x[1]
        f1 = - dV1 - dV2
        return np.array([f0, f1])

    sol = ode(f, initial_cond, t, rtol = 1e-13, atol = 1e-13)
    return sol

k = 39.48
t0 = 0.
tf = 4.
dt = 0.01
t = np.arange(t0, tf, dt)
initial_cond1 = [0., 10.]
p1 = 2.
p2 = 6.

sol1 = osc(initial_cond1, t, p1)
sol2 = osc(initial_cond1, t, p2)
x1, v1 = sol1[:, 0], sol1[:, 1]
x2, v2 = sol2[:, 0], sol2[:, 1]

plt.plot(t, x1, '-r', label = 'p = 2')
plt.plot(t, x2, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$x(t)$', size = 16)
plt.title(r'$x(t)$ for p = 2 and p = 6', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t, v1, '-r', label = 'p = 2')
plt.plot(t, v2, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$v(t)$', size = 16)
plt.title(r'$v(t)$ for p = 2 and p = 6', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q1.2
def E(x, v, p):
    # K = np.zeros(len(t))
    # U = np.zeros(len(t))
    K = 0.5 * v**2.
    U = 1. / p * k * x**p
    Etot = K + U
    return Etot

Etot1 = E(x1, v1, p1)
Etot2 = E(x2, v2, p2)

dEtot1 = np.abs(np.max(Etot1) - np.min(Etot1))
dEtot2 = np.abs(np.max(Etot2) - np.min(Etot2))

E1 = np.abs((Etot1[:] - Etot1[0]) / Etot1[0])
E2 = np.abs((Etot2[:] - Etot2[0]) / Etot2[0])

plt.plot(t, E1, '-r', label = r'p = 2, $\Delta E = {:.2e}$'.format(dEtot1))
plt.plot(t, E2, '-b', label = r'p = 6, $\Delta E = {:.2e}$'.format(dEtot2))
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$E(t)$', size = 16)
plt.title(r'$E(t)/E(0) - 1$ for p = 2 and p = 6', size = 16)
plt.legend(loc = 'lower right')
plt.tight_layout()
plt.show()

#%%             Q1.3
def KU(x, v, p):
    # K = np.zeros(len(t))
    # U = np.zeros(len(t))
    K = 0.5 * v**2.
    U = 1. / p * k * x**p
    return K, U

n = 20
t0 = 0.
tf = 40.
dt = 0.01
tavr = np.arange(t0, tf, dt)
soln = np.zeros((len(tavr), 2, n))
for i in range(n):
    soln[:, :, i] = osc(initial_cond1, tavr, p2)
solf = np.average(soln, axis = 2)
xf, vf = solf[:, 0], solf[:, 1]

K, U = KU(xf, xf, p2)
Kavr = np.average(K)
Uavr = np.average(U)
print(3 * Uavr - Kavr)

#%%             Q1.4
Fext = True
F0 = 5.
omega = 7.
p3 = 2.
p4 = 4.
t0 = 0.
tf = 12.
dt = 0.01
t2 = np.arange(t0, tf, dt)

sol3 = osc(initial_cond1, t2, p3, Fext)
sol4 = osc(initial_cond1, t2, p4, Fext)
x3, v3 = sol3[:, 0], sol3[:, 1]
x4, v4 = sol4[:, 0], sol4[:, 1]

plt.plot(t2, x3, '-r', label = 'p = 2')
plt.plot(t2, x4, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$x(t)$', size = 16)
plt.title(r'$x(t)$ for p = 2 and p = 4', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t2, v3, '-r', label = 'p = 2')
plt.plot(t2, v4, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$v(t)$', size = 16)
plt.title(r'$v(t)$ for p = 2 and p = 4', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q1.5
Fext = True
F0 = 5.
omega = 2. * np.pi
p3 = 2.
p4 = 4.
t0 = 0.
tf = 12.
dt = 0.01
t2 = np.arange(t0, tf, dt)

sol3 = osc(initial_cond1, t2, p3, Fext)
sol4 = osc(initial_cond1, t2, p4, Fext)
x3, v3 = sol3[:, 0], sol3[:, 1]
x4, v4 = sol4[:, 0], sol4[:, 1]

plt.plot(t2, x3, '-r', label = 'p = 2')
plt.plot(t2, x4, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$x(t)$', size = 16)
plt.title(r'$x(t)$ for p = 2 and p = 4', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

plt.plot(t2, v3, '-r', label = 'p = 2')
plt.plot(t2, v4, '-b', label = 'p = 6')
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$v(t)$', size = 16)
plt.title(r'$v(t)$ for p = 2 and p = 4', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q2.1
def s(t):
    return 1. / (1 - 0.9 * np.sin(t))

def exps(t, n):
    en = np.arange(n + 1)
    exps = 0.
    for i in en:
        exps += (0.9 * np.sin(t))**i
    return exps

N = int(24000)
t0 = 0.
tf = 12.
t = np.linspace(t0, tf, N)
sample_rate = N / tf
n1 = int(10)
n2 = int(20)
n3 = int(30)

x = s(t)
expx1 = exps(t, n1)
expx2 = exps(t, n2)
expx3 = exps(t, n3)

plt.plot(t, x, '-r', label = 's(t)')
plt.plot(t, expx1, label = 's(t) for n = {}'.format(n1))
plt.plot(t, expx2, label = 's(t) for n = {}'.format(n2))
plt.plot(t, expx3, label = 's(t) for n = {}'.format(n3))
plt.xlabel(r'$t$', size = 16)
plt.ylabel(r'$s(t)$', size = 16)
plt.title(r'$s(t)$ and its expansions', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%             Q2.2
ck = fft.rfft(s(t) - np.mean(s(t)))

Sk = np.abs(ck)**2.
ckmax = np.argmax(Sk)
fmax = ckmax / N * sample_rate

ks = fft.rfftfreq(N, d = 1. / sample_rate)

plt.plot(Sk, label = 'fmax = {:.3f}'.format(fmax))
# plt.scatter(ks[1:20], Sk[1:20], label = 'fmax = {:.3f}'.format(fmax))
plt.xlabel(r'$f(Hz)$', size = 16)
plt.ylabel(r'$S(k) = |c(k)|^2$', size = 16)
plt.title(r'$s(t)$ and its expansions', size = 16)
plt.legend(loc = 'lower right')
plt.yscale('log')
plt.tight_layout()
plt.show()





