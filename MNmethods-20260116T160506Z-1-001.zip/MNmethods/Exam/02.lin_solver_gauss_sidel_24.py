# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 00:15:45 2024

@author: Nicholas
"""

import numpy as np
from numpy.linalg import solve
from numpy.linalg import norm

def gauss_seidel(A, b, tol = 1e-7):
    
    x = np.zeros(len(b), float)
    xtemp = np.ones(len(b), float)
    niter = 0
    niter_limit = 1e3
    
    while ((norm(x - xtemp)) > tol) and (niter <= niter_limit):
        xtemp = np.copy(x)
        for i in range(len(x)):
            sumx = 0.
            for j in range(len(x)):
                if (j != i):
                    sumx += + A[i, j] * x[j]    # using x[j] is much faster then using xtemp[j]
            x[i] = (b[i] - sumx) / A[i, i] 
        niter += 1
        print(x)
    
    if (niter <= niter_limit):
        print('Solution:', x,'\nReached in', niter, 'iterations.')
    else:
        print('No convergence reached in', niter_limit, 'iterations.')
        
    return x

#%%
A = np.array([[4., -1., 1.], [-1., 4., -2.], [1., -2., 4.]])
b = np.array([12., -1., 5])

gauss_seidel(A, b)

x = solve(A, b)

print(x)