# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 23:29:29 2025

@author: Nicholas
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad as quad
import scipy.optimize as opt

#%%         Q1.1
def rk4(f, t0, tf, N, x0, y0):
    
    h = (tf - t0) / N
    t = np.arange(t0, tf, h)
    xt = np.zeros((N + 1, 2), float)
    xt[0, 0] = x0
    xt[0, 1] = y0
    
    for i in range(1, len(t) + 1):
        k1 = 0.5 * h * f(xt[i - 1], t[i - 1])
        k2 = 0.5 * h * f(xt[i - 1] + k1, t[i - 1] + 0.5 * h)
        k3 = h * f(xt[i - 1] + k2, t[i - 1] + 0.5 * h)
        k4 = h * f(xt[i - 1] + k3, t[i - 1] + h)
        xt[i] = xt[i - 1] + (2. * k1 + 4. * k2 + 2. * k3 + k4) / 6.
    
    return t, xt[:-1]

def g(theta, xi, n):
    f0 = theta[1]
    if xi <= 1e-5:
        f1 = -theta[0]**n
    else:
        f1 = -2. / xi * theta[1] - theta[0]**n
    return np.array([f0, f1])

xi0 = 0.
xif = 10.
N = int(1e3)
theta0 = 1.
theta1 = 0.

def f1(theta, xi):
    n = 1
    return g(theta, xi, n)
sol1 = rk4(f1, xi0, xif, N, theta0, theta1)

def fa1(xi):
    if xi.any() < 1e-10:
        return 1.
    else:
        return np.sin(xi)/xi
xi = sol1[0]
theta = sol1[1]

plt.plot(xi, theta[:, 0], '-r', label = 'Solution from RK4')
plt.plot(xi, fa1(xi), ':k', label = r'Analitical solution $j_0(\xi)$')
plt.xlabel(r'$\xi$', size = 16)
plt.ylabel(r'$\Theta(\xi)$', size = 16)
plt.title('Lane-Emden n = 1', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%%         Q1.2
def f5(theta, xi):
    n = 5
    return g(theta, xi, n)
sol2 = rk4(f5, xi0, xif, N, theta0, theta1)

def fa5(xi):
    return 1. / np.sqrt(1 + xi**2. / 3.)
xi = sol2[0]
theta = sol2[1]

plt.plot(xi, theta[:, 0], '-r', label = 'Solution from RK4')
plt.plot(xi, fa5(xi), ':k', label = 'Analitical solution')
plt.xlabel(r'$\xi$', size = 16)
plt.ylabel(r'$\Theta(\xi)$', size = 16)
plt.title('Lane-Emden n = 5', size = 16)
plt.legend(loc = 'upper right')
plt.tight_layout()
plt.show()

#%% Q2.1
def f(E, mu, kt):
    return 1. / (np.exp((E - mu)/kt) + 1.)

def g(mu):
    kt = 1. / 40.
    Emin = 0.
    Emax = 2.
    G = quad(f, Emin, Emax, args = (mu, kt))
    return G[0]
    # return quad(f, Emin, Emax, args = (mu, kt))[0]

def func(mu):
    return g(mu) - 1.

root = opt.root_scalar(func, method = 'bisect', bracket = [0, 3])
print('Root = {0:.4f}'.format(root.root))

MU = np.linspace(0., 5., 1000)
GI = []
for i in range(len(MU)):
    GI.append(g(MU[i]))

plt.plot(MU, GI, '-r', label = 'Fermi-Dirac distribution')
plt.axhline(y = 1., ls = 'dashed', color = 'k', lw = 1)
plt.axvline(x = root.root, ls = 'dashed', color = 'k', lw = 1)
plt.xlabel(r'$\mu$', size = 16)
plt.legend(loc = 'lower right')
plt.tight_layout()
plt.show()




