# -*- coding: utf-8 -*-
"""
Created on Fri Mar 29 18:22:05 2024

@author: Nicholas
"""

import numpy as np
import math
import matplotlib.pyplot as plt

def rk1(t0, tf, x0, h):
    
    N = int((tf - t0) / h)

    xt = np.zeros(N, float)
    t = np.arange(t0, tf, h)
    xt[0] = x0
    
    for i in range(1, len(xt)):
        xt[i] = xt[i - 1] + h * f(xt[i - 1], t[i - 1])
    
    return xt

def rk2(t0, tf, x0, h):
    
    N = int((tf - t0) / h)

    xt = np.zeros(N, float)
    t = np.arange(t0, tf, h)
    xt[0] = x0
    
    for i in range(1, len(xt)):
        k1 = 0.5 * h * f(xt[i - 1], t[i - 1])
        k2 = h * f(xt[i - 1] + k1, t[i - 1] + 0.5 * h)
        xt[i] = xt[i - 1] + k2
    
    return xt

def rk4(t0, tf, x0, h):
    
    N = int((tf - t0) / h)

    xt = np.zeros(N, float)
    t = np.arange(t0, tf, h)
    xt[0] = x0
    
    for i in range(1, len(xt)):
        k1 = 0.5 * h * f(xt[i - 1], t[i - 1])
        k2 = 0.5 * h * f(xt[i - 1] + k1, t[i - 1] + 0.5 * h)
        k3 = h * f(xt[i - 1] + k2, t[i - 1] + 0.5 * h)
        k4 = h * f(xt[i - 1] + k3, t[i - 1] + h)
        xt[i] = xt[i - 1] + (2. * k1 + 4. * k2 + 2. * k3 + k4) / 6.
    
    return xt

def f(x, t):
    return - x**3. + np.sin(t)

#%%%
t0 = 0.
tf = 100.
x0 = 0.
h = 0.1

t = np.arange(t0, tf, h)

xeul = rk1(t0, tf, x0, h)

xrk2 = rk2(t0, tf, x0, h)

xrk4 = rk4(t0, tf, x0, h)

font = {'family': 'serif',
        'color':  'k',
        'size': 12,
        }
plt.plot(t, xeul, 'b-', label = 'Euler')
plt.plot(t, xrk2, 'g-', label = 'Midpoint')
plt.plot(t, xrk4, 'r-', label = 'Runge-Kutta 4')
plt.xlim((t0, tf))
plt.xlabel('t', fontdict = font)
plt.ylabel('x', fontdict = font)
plt.locator_params(axis = 'y', nbins = 6)
plt.locator_params(axis = 'x', nbins = 8)
plt.legend(loc = 'lower right')

plt.tight_layout()
plt.show()
