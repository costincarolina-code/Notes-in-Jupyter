# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 18:33:14 2024

@author: Nicholas
"""
import numpy as np
from numpy.linalg import solve
import time

def gauss_elim(A, b):
    
    x = np.zeros(len(b), float)
    
    start = time.time()
    
    for i in range(len(x)):
        piv = np.argmax(abs(A[:, i]))
        if (piv > i):
            A[[i, piv]] = A[[piv, i]]
            b[[i, piv]] = b[[piv, i]]
        temp = A[i, i]
        A[i, :] /= temp
        b[i] /= temp
        for j in range(i + 1, len(x)):
            temp = A[j, i]
            A[j, :] -= temp * A[i, :]
            b[j] -= temp * b[i]
    
    for i in range(len(x) - 1, -1, -1):
        x[i] = b[i]
        for j in range(len(x) - 1, i, -1):
            x[i] = x[i] - A[i, j] * x[j]
    
    end = time.time()
    t = end - start
    
    return x, t

#%%
A = np.array([[2., 1., 4., 1.], [3., 4., -1., -1.], [1., -4., 1., 5.], [2., -2., 1., 3.]])
b = np.array([-4., 3., 9., 7.])

x, t = gauss_elim(A, b)
print(x, t)

start = time.time()
x = solve(A, b)
end = time.time()
t = end - start

print(x, t)
